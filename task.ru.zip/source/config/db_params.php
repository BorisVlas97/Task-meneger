<?php

return array ('host' => 'localhost',
			'dbname' => 'task_db',
			'user' => 'root',
			'password' => '');